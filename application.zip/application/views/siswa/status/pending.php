<div class="card widget widget-info shadow">
	<div class="card-body">
		<div class="widget-info-container">
			<div class="widget-info-image" style="background: url('https://assets.pikiran-rakyat.com/crop/0x0:0x0/750x500/photo/2022/02/11/630498307.png"></div>
			<h5 class="widget-info-title">Berkas anda sedang di verifikasi</h5>
			<p class="widget-info-text">Menunggu approve dari admin, informasi akan dikirim melalui whatsapp dan email.</p>
			<button class="btn btn-warning" type="button" disabled>
				<span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="true"></span>
				Mohon untuk menunggu...
			</button>
		</div>
	</div>
</div>
